package com.DomainExcercise.SwipeService.mongoRepository;

import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.UUID;

public interface SwipeRepository extends MongoRepository<SwipeEvent, UUID> {
}
