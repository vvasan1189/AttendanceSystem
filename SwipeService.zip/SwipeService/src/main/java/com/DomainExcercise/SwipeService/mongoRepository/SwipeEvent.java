package com.DomainExcercise.SwipeService.mongoRepository;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.UUID;
import java.util.Date;

@Document(collection = "swipe_events")
public class SwipeEvent {

    @Id
    private UUID id;
    private UUID employeeId;
    private Date timestamp;
    private String eventType;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public void setEmployeeId(UUID employeeId) {
        this.employeeId = employeeId;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public UUID getEmployeeId() {
        return employeeId;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public String getEventType() {
        return eventType;
    }
}
