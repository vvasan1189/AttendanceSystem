package com.DomainExcercise.SwipeService.controller;

import com.DomainExcercise.SwipeService.service.SwipeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

@RestController
@RequestMapping("/swipe")
public class SwipeController {

    private static final Logger logger = LoggerFactory.getLogger(SwipeController.class);

    @Autowired
    private SwipeService swipeService;

    @PostMapping("/in/{employeeId}")
    public ResponseEntity<String> swipeIn(@PathVariable UUID employeeId) {
        try {
            logger.info("Received swipe out data: {}", employeeId);
            swipeService.swipeIn(employeeId);
        } catch (Exception e) {
            logger.error("Error processing swipe in data", e);
            throw new RuntimeException("Swipe in processing failed");
        }
        return ResponseEntity.ok("Swiped In");
    }

    @PostMapping("/out/{employeeId}")
    public ResponseEntity<String> swipeOut(@PathVariable UUID employeeId) {
        try {
            logger.info("Received swipe out data: {}", employeeId);
            swipeService.swipeOut(employeeId);
        } catch (Exception e) {
            logger.error("Error processing swipe out data", e);
            throw new RuntimeException("Swipe out processing failed");
        }
        return ResponseEntity.ok("Swiped Out");
    }
}
