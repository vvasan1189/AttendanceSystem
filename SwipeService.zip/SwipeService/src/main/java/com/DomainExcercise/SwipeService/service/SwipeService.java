package com.DomainExcercise.SwipeService.service;

import com.DomainExcercise.SwipeService.mongoRepository.SwipeEvent;
import com.DomainExcercise.SwipeService.mongoRepository.SwipeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.UUID;

@Service
public class SwipeService {
    @Autowired
    private SwipeRepository swipeRepository;

    public void swipeIn(UUID employeeId) {
        SwipeEvent event = new SwipeEvent();
        event.setId(UUID.randomUUID());
        event.setEmployeeId(employeeId);
        event.setTimestamp(new Date());
        event.setEventType("IN");
        swipeRepository.save(event);
    }

    public void swipeOut(UUID employeeId) {
        SwipeEvent event = new SwipeEvent();
        event.setId(UUID.randomUUID());
        event.setEmployeeId(employeeId);
        event.setTimestamp(new Date());
        event.setEventType("OUT");
        swipeRepository.save(event);
    }
}
