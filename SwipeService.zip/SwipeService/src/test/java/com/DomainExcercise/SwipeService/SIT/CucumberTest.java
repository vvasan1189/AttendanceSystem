package com.DomainExcercise.SwipeService.SIT;

public class CucumberTest {
}
