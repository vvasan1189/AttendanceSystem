package com.DomainExcercise.SwipeService.Junits;

import static org.mockito.Mockito.doThrow;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.DomainExcercise.SwipeService.controller.SwipeController;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

public class SwipeControllerTest {

    private MockMvc mockMvc;


    @Mock
    private Logger logger;

    @InjectMocks
    private SwipeController swipeController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(swipeController).build();
    }

    @Test
    public void testSwipeSuccess() throws Exception {
        mockMvc.perform(post("/swipe")
                        .contentType("application/json")
                        .content("{\"data\":\"test\"}"))
                .andExpect(status().isOk());
    }

    @Test
    public void testSwipeFailure() throws Exception {
        mockMvc.perform(post("/swipe")
                        .contentType("application/json")
                        .content("{\"data\":\"test\"}"))
                .andExpect(status().isInternalServerError());
    }

    @Test
    public void testSwipeWithNullInput() throws Exception {
        mockMvc.perform(post("/swipe")
                        .contentType("application/json")
                        .content("null"))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void testSwipeWithEmptyInput() throws Exception {
        mockMvc.perform(post("/swipe")
                        .contentType("application/json")
                        .content("{}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void testSwipeWithInvalidJson() throws Exception {
        mockMvc.perform(post("/swipe")
                        .contentType("application/json")
                        .content("{invalid}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void testSwipeLogging() throws Exception {
        mockMvc.perform(post("/swipe")
                        .contentType("application/json")
                        .content("{\"data\":\"test\"}"))
                .andExpect(status().isOk());

    }
}