package com.DomainExcercise.SwipeService.Junits;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.DomainExcercise.SwipeService.exception.GlobalExceptionHandler;
import com.DomainExcercise.SwipeService.controller.SwipeController;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

public class GlobalExceptionHandlerTest {

    private MockMvc mockMvc;

    @BeforeEach
    public void setUp() {

        SwipeController swipeController = new SwipeController();
        mockMvc = MockMvcBuilders.standaloneSetup(swipeController)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    @Test
    public void testHandleException() throws Exception {
        mockMvc.perform(post("/swipe/in")
                        .contentType("application/json")
                        .content("{\"data\":\"test\"}"))
                .andExpect(status().isInternalServerError());
    }

    @Test
    public void testHandleNullPointerException() throws Exception {
        mockMvc.perform(post("/swipe/in")
                        .contentType("application/json")
                        .content("null"))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void testHandleInvalidJsonException() throws Exception {
        mockMvc.perform(post("/swipe/in")
                        .contentType("application/json")
                        .content("{invalid}"))
                .andExpect(status().isBadRequest());
    }
    @Test
    public void testHandleExceptionOut() throws Exception {
        mockMvc.perform(post("/swipe/out")
                        .contentType("application/json")
                        .content("{\"data\":\"test\"}"))
                .andExpect(status().isInternalServerError());
    }

    @Test
    public void testHandleNullPointerExceptionOut() throws Exception {
        mockMvc.perform(post("/swipe/out")
                        .contentType("application/json")
                        .content("null"))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void testHandleInvalidJsonExceptionOut() throws Exception {
        mockMvc.perform(post("/swipe/out")
                        .contentType("application/json")
                        .content("{invalid}"))
                .andExpect(status().isBadRequest());
    }
}

