package com.DomainExcercise.SwipeService.SIT.steps;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import com.DomainExcercise.SwipeService.controller.SwipeController;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

public class SwipeServiceSteps {

    private MockMvc mockMvc;


    @InjectMocks
    private SwipeController swipeController;

    private MvcResult mvcResult;

    @Given("the swipe service is running")
    public void theSwipeServiceIsRunning() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(swipeController).build();
    }

    @When("I send a valid swipe data")
    public void iSendAValidSwipeData() throws Exception {
        mvcResult = mockMvc.perform(post("/swipe/in")
                        .contentType("application/json")
                        .content("{\"data\":\"test\"}"))
                .andReturn();
    }

    @When("I send an invalid JSON")
    public void iSendAnInvalidJSON() throws Exception {
        mvcResult = mockMvc.perform(post("/swipe/in")
                        .contentType("application/json")
                        .content("{invalid}"))
                .andReturn();
    }

    @When("I send a null input")
    public void iSendANullInput() throws Exception {
        mvcResult = mockMvc.perform(post("/swipe/in")
                        .contentType("application/json")
                        .content("null"))
                .andReturn();
    }

    @When("I send an empty input")
    public void iSendAnEmptyInput() throws Exception {
        mvcResult = mockMvc.perform(post("/swipe/in")
                        .contentType("application/json")
                        .content("{}"))
                .andReturn();
    }

    @Then("I should receive a {int} {string} response")
    public void iShouldReceiveAResponse(int statusCode, String statusMessage) throws Exception {
        assertThat(mvcResult.getResponse().getStatus()).isEqualTo(statusCode);
    }

    @When("I send a valid swipe data")
    public void iSendAValidSwipeDataOut() throws Exception {
        mvcResult = mockMvc.perform(post("/swipe/out")
                        .contentType("application/json")
                        .content("{\"data\":\"test\"}"))
                .andReturn();
    }

    @When("I send an invalid JSON")
    public void iSendAnInvalidJSONOut() throws Exception {
        mvcResult = mockMvc.perform(post("/swipe/out")
                        .contentType("application/json")
                        .content("{invalid}"))
                .andReturn();
    }

    @When("I send a null input")
    public void iSendANullInputOut() throws Exception {
        mvcResult = mockMvc.perform(post("/swipe/out")
                        .contentType("application/json")
                        .content("null"))
                .andReturn();
    }

    @When("I send an empty input")
    public void iSendAnEmptyInputOut() throws Exception {
        mvcResult = mockMvc.perform(post("/swipe/out")
                        .contentType("application/json")
                        .content("{}"))
                .andReturn();
    }
}
